import copy
import pytest
import algorithms as alg
import test_cases as tc


def valid_sequence(available, allocation, maximum, seq):
    """Independent check that a sequence really is safe."""
    need = alg.calculate_need(maximum, allocation)
    work = list(available)
    for i in seq:
        if any(need[i][j] > work[j] for j in range(len(work))):
            return False
        work = [work[j] + allocation[i][j] for j in range(len(work))]
    return sorted(seq) == list(range(len(allocation)))


def tc1():
    return copy.deepcopy(tc.TC1_DATA)


# ---------- basics
def test_need_matrix():
    d = tc1()
    need = alg.calculate_need(d["maximum"], d["allocation"])
    assert need[0] == [7, 4, 3] and need[1] == [1, 2, 2] and need[4] == [4, 3, 1]


def test_tc1_safe():
    d = tc1()
    r = alg.check_safe_state(d["available"], d["allocation"], d["maximum"])
    assert r["status"] == alg.SAFE
    assert valid_sequence(d["available"], d["allocation"], d["maximum"], r["safe_sequence"])
    assert r["safe_sequence"] == [1, 3, 4, 0, 2]


def test_unsafe_is_not_deadlock_label():
    r = alg.check_safe_state([0], [[0], [1]], [[2], [2]])
    assert r["status"] == alg.UNSAFE and r["status"] != alg.DEADLOCK


# ---------- TC2
def test_tc2_insufficient_available():
    d = tc1()
    before = copy.deepcopy(d)
    r = alg.request_resources(0, [0, 4, 0], d["available"], d["allocation"], d["maximum"])
    assert r["status"] == alg.DENIED_AVAILABLE and r["original_state"]["need"][0] == [7, 4, 3]
    assert r["state_unchanged"] and d == before


# ---------- TC3
def test_tc3_unsafe_and_rollback():
    d = copy.deepcopy(tc.TC3_DATA)
    before = copy.deepcopy(d)
    assert alg.check_safe_state(d["available"], d["allocation"], d["maximum"])["status"] == alg.SAFE
    r = alg.request_resources(0, [1], d["available"], d["allocation"], d["maximum"])
    assert r["status"] == alg.DENIED_UNSAFE
    t = r["tentative_state"]
    assert t["allocation"] == [[1], [1]] and t["available"] == [0] and t["need"] == [[1], [1]]
    assert r["final_state"]["allocation"] == [[0], [1]] and r["final_state"]["available"] == [1]
    assert d == before and r["state_unchanged"]


def test_granted_request_changes_returned_state_only():
    d = tc1()
    before = copy.deepcopy(d)
    r = alg.request_resources(1, [1, 0, 2], d["available"], d["allocation"], d["maximum"])
    assert r["status"] == alg.GRANTED
    assert r["final_state"]["available"] == [2, 3, 0]
    assert r["final_state"]["allocation"][1] == [3, 0, 2]
    assert d == before  # inputs untouched


# ---------- TC4
def test_tc4_detection():
    d = tc.TC4_DATA
    r = alg.detect_deadlock(d["available"], d["allocation"], d["request"])
    assert r["status"] == alg.DEADLOCK and r["deadlocked"] == [0, 1]


def test_tc4_recovery():
    d = copy.deepcopy(tc.TC4_DATA)
    r = alg.recover_from_deadlock(0, d["available"], d["allocation"], d["request"])
    assert r["new_available"] == [1, 0] and r["recovered"] is True
    assert r["after"]["status"] == alg.NO_DEADLOCK and r["after"]["finish_order"] == [1]
    assert d == tc.TC4_DATA


def test_detection_uses_request_not_need():
    # Request matrix is all zeros -> nobody is waiting -> no deadlock, even though Need > 0.
    r = alg.detect_deadlock([0, 0], [[1, 0], [0, 1]], [[0, 0], [0, 0]])
    assert r["status"] == alg.NO_DEADLOCK


# ---------- TC5
def test_tc5_ordering():
    order = ["A", "B", "C"]
    assert alg.check_resource_order(order, [], "A")["status"] == alg.ALLOWED
    assert alg.check_resource_order(order, ["A"], "B")["status"] == alg.ALLOWED
    assert alg.check_resource_order(order, ["B"], "A")["status"] == alg.REJECTED
    assert alg.check_resource_order(order, ["A"], "Z")["status"] == alg.INVALID


# ---------- TC6 subtests
def test_tc6_a_zero_available_zero_need():
    r = alg.check_safe_state([0], [[1]], [[1]])
    assert r["status"] == alg.SAFE and r["safe_sequence"] == [0]


def test_tc6_b_zero_request_noop():
    r = alg.request_resources(0, [0], [1], [[0]], [[1]])
    assert r["status"] == alg.GRANTED and r["no_op"] and r["state_unchanged"]


def test_tc6_c_invalid_process():
    assert alg.request_resources(9, [1], [1], [[0]], [[1]])["status"] == alg.INVALID


def test_tc6_d_negative_request():
    assert alg.request_resources(0, [-1], [1], [[0]], [[1]])["status"] == alg.INVALID


def test_tc6_e_exceeds_need():
    r = alg.request_resources(0, [2], [1], [[1]], [[2]])
    assert r["status"] == alg.DENIED_NEED and r["state_unchanged"]


def test_tc6_f_allocation_exceeds_maximum():
    assert alg.check_safe_state([1], [[2]], [[1]])["status"] == alg.INVALID
    assert alg.request_resources(0, [0], [1], [[2]], [[1]])["status"] == alg.INVALID


def test_tc6_g_unavailable_not_deadlock():
    r = alg.request_resources(0, [1], [0], [[0]], [[1]])
    assert r["status"] == alg.DENIED_AVAILABLE and r["status"] != alg.DEADLOCK


# ---------- validation
def test_invalid_dimensions():
    assert alg.validate_input([1, 1], [[0, 0]], [[1]])[0] is False
    assert alg.check_safe_state([1, 1], [[0, 0], [0]], [[1, 1], [1, 1]])["status"] == alg.INVALID
    assert alg.validate_input([1], [[0], [0]], [[1]])[0] is False
    assert alg.detect_deadlock([0], [[1]], [[1], [1]])["status"] == alg.INVALID


def test_negative_resource_counts():
    assert alg.validate_input([-1], [[0]], [[1]])[0] is False
    assert alg.validate_input([1], [[-1]], [[1]])[0] is False
    assert alg.validate_input([1], [[0]], [[-1]])[0] is False
    assert alg.detect_deadlock([0], [[1]], [[-1]])["status"] == alg.INVALID


def test_allocation_exceeds_maximum():
    ok, errs = alg.validate_input([1], [[3]], [[2]])
    assert not ok and "exceeds" in errs[0]


def test_malformed_input_does_not_crash():
    for bad in (None, "x", [], [[]], [None], [[1.5]]):
        assert alg.validate_input(bad, bad, bad)[0] is False
        assert alg.check_safe_state(bad, bad, bad)["status"] == alg.INVALID
    assert alg.request_resources("zz", [1], [1], [[0]], [[1]])["status"] == alg.INVALID
    assert alg.request_resources(0, "bad", [1], [[0]], [[1]])["status"] == alg.INVALID
    assert alg.request_resources(0, [1, 1], [1], [[0]], [[1]])["status"] == alg.INVALID


# ---------- no mutation after denial (all denial types)
@pytest.mark.parametrize("pid,req,available,alloc,mx", [
    (0, [0, 4, 0], tc.TC1_DATA["available"], tc.TC1_DATA["allocation"], tc.TC1_DATA["maximum"]),
    (0, [8, 0, 0], tc.TC1_DATA["available"], tc.TC1_DATA["allocation"], tc.TC1_DATA["maximum"]),
    (0, [1], [1], [[0], [1]], [[2], [2]]),
    (7, [1], [1], [[0], [1]], [[2], [2]]),
    (0, [-1], [1], [[0], [1]], [[2], [2]]),
])
def test_denied_requests_do_not_mutate(pid, req, available, alloc, mx):
    a, b, c = copy.deepcopy(available), copy.deepcopy(alloc), copy.deepcopy(mx)
    r = alg.request_resources(pid, req, a, b, c)
    assert not r["granted"]
    assert (a, b, c) == (available, alloc, mx)
    assert r["state_unchanged"]


# ---------- the dashboard runners agree with the spec
@pytest.mark.parametrize("name", ["run_tc1", "run_tc2", "run_tc3", "run_tc4", "run_tc5", "run_tc6"])
def test_runners_pass(name):
    assert getattr(tc, name)()["passed"] is True


def test_tc6_has_seven_subtests():
    assert len(tc.run_tc6()["subtests"]) == 7
